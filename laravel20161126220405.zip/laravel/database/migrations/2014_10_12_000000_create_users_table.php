<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            /*uid MEDIUMINT not null,
uname VARCHAR(64) not null,
password CHAR(96) not null,
email VARCHAR(128) not null,
PRIMARY KEY(uid),
UNIQUE(uname));*/
            //$table->mediumIncrements('uid')->primary();
            $table->mediumIncrements('uid'); //big increments defines it as primary key
            $table->string('uname', 64)->unique();
            $table->string('password', 96);
            $table->string('email', 128);
            $table->rememberToken()->index();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
