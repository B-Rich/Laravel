<?php

namespace App\Http\Controllers;

use App\users;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function create(){
        return view('user.create');
    }

    //handle form input
    public function store(){
        $FormData = Input::all();
        $FormValidator = Validator::make($FormData,
        ['uname' => 'required|unique:users|min:4|regex:/^[a-zA-Z0-9_-]{3,15}$/',
        'email' => 'required|email|unique:users|confirmed',
        'password' => 'required|confirmed|min:8']);
        if($FormValidator->fails()){
            return Redirect::back()->withErrors($FormValidator)->withInput($FormData);
        }
        $FormData['password'] = Hash::make($FormData['password']);
        $RegisteredUser = users::create($FormData);
        return Redirect::to('login')->with('alert','Registered successfully, you may now login');
    }
}
