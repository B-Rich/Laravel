<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    //
    public $timestamps = false;
    protected $table = 'users';
    protected $guarded = ['uid'];
    protected $fillable = ['uname', 'email', 'password'];
}
