<?php

namespace App;

use DB;
use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    //
    public $timestamps = true;
    protected $table = 'users';
    protected $guarded = ['id'];
    protected $fillable = ['uname', 'email', 'password', 'confirmation_token'];

    public static function activate($confirmation_token){
        $user = users::whereConfirmationToken($confirmation_token)->first();
        //echo $user;
        $uid = $user['id'];
        if($user){
            $user->is_confirmed = 1;
            $user->confirmation_token = NULL;
            //$user->save();
            DB::table('users')->where('id',$uid)->update(['is_confirmed' => 1]);
            DB::table('users')->where('id',$uid)->update(['confirmation_token' => NULL]);
            return true;
        }else{
            return false;
        }
    }
}
