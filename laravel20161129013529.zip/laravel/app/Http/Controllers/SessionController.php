<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;

class SessionController extends Controller
{
    //
    public function create(){
        return view('session.create');
    }
    public function store(){
        $attempt = Auth::attempt([
            'uname' => Input::get('uname'),
            'password' => Input::get('password'),
            'is_confirmed' => 1
        ],Input::get('remember_me')==1);
        if ($attempt){
            return Redirect::intended('/')->with('alert','You have been logged in');
        }else{
            return Redirect::back()
                ->with('alert','Invalid Username or Password')
                ->withInput();
        }

    }
    public function destroy(){
        Auth::logout();
        return Redirect::to('/')->with('alert','You have been logged out');
    }
}
