<?php

namespace App\Http\Controllers;

use App\users;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function create(){
        return view('user.create');
    }

    //handle form input
    public function store(){
        $FormData = Input::all();
        $FormValidator = Validator::make($FormData,
        ['uname' => 'required|unique:users|min:4|regex:/^[a-zA-Z0-9_-]{3,15}$/',
        'email' => 'required|email|unique:users|confirmed',
        'password' => 'required|confirmed|min:8']);
        if($FormValidator->fails()){
            return Redirect::back()->withErrors($FormValidator)->withInput($FormData);
        }
        $FormData['password'] = Hash::make($FormData['password']);
        $FormData['confirmation_token'] = sha1(uniqid($FormData['email'],true));

        \Mail::send('email.activate',$FormData,function($message) use ($FormData){
            $message->to($FormData['email'])->subject('Please verify your E-mail address');
        });

        $RegisteredUser = users::create($FormData);
        return Redirect::to('login')->with('alert','Registered successfully, you may now login');
    }

    public function show(){
        return view('user.show',['user' => Auth::user()]);
    }


    public function activate($confirmation_token){
        if(users::activate($confirmation_token)){
            return Redirect::to('login')->with('alert','Account activated, you may now login');
        }else{
            return Redirect::to('/')->with('alert','Account activation code not found');
        }
    }

}
