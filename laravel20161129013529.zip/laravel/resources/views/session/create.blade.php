<!--@section('content')-->
<!DOCTYPE html>
<html>
<head>
    <title>Complec City - Log In</title>
    <style type="text/css">
        .form {
            background-color: black;
            color: white;
            margin: 4%;
            padding: 20px;
            opacity: .9;

        }

        #div1 {
            background-color: black;
            color: white;
            opacity: .9;
            width: 300px;

        }
        div {
            background-color: black;
            color: white;

        }
        p {
            font-family: arial;
        }
        h {
            font-family: impact;
            padding: 10px;
            font-size: 40px;
        }
        p#footer-txt {
            text-align: center;
            color: #303032;
            font-family: arial;
            font-size: 12px;
            padding: 0 32px;
            background-color: Black;
            color: white;
            margin-top: 21%;
            opacity: .9;
        }
        .home{
            font-family: impact;
            padding: 10px;
            font-size: 40px;
            text-decoration: none;
            color: white;
        }

    </style>


</head>
<body>

<div >
    <!--<a class="home" href="{{url('/')}}">Complec-City</a>-->

</div>
{{Form::open(array('route' => 'session.store'))}}
<input type ="hidden" name="_token" value="{{csrf_token()}}">
@include('alerts')
<div>
    {{Form::label('uname','Username')}}
    {{Form::text('uname',
    Input::old('uname')/*,
     ['placeholder' => 'Enter your username',
    'autofocus' => 'autofocus']*/)}}
</div>
<div>
    {{Form::label('password','Password')}}
    {{Form::password('password'/*, ['placeholder' => 'Enter your password']*/)}}
    <br>
    {{Form::label('remember_me','Remember me')}}
    {{Form::checkbox('remember_me','Remember me')}}
</div>
<div>
    {{Form::submit('Login')}}
</div>
{{Form::close()}}
<p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>
    <br>
    <a href="@">Contact us</a>
    <a href="@"> </a>
    <a href="@"> Developers </a>

    <a href="@"> Privacy </a>
    <a href="@"> Terms </a>
    <a href="@"> Help </a>

</p>
</body>
</html>
