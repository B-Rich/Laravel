<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            /*uid MEDIUMINT not null,
uname VARCHAR(64) not null,
password CHAR(96) not null,
email VARCHAR(128) not null,
PRIMARY KEY(uid),
UNIQUE(uname));*/
            //$table->mediumIncrements('uid')->primary();
            $table->mediumIncrements('id'); //big increments defines it as primary key
            $table->string('uname', 64)->unique();
            $table->string('password', 96);
            $table->string('email', 128);
            $table->rememberToken()->index();
            $table->boolean('is_confirmed');
            $table->string('confirmation_token',40)->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
