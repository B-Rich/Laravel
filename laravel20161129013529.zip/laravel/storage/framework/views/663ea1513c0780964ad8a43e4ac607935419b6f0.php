<!--<?php $__env->startSection('content'); ?>-->
<!DOCTYPE html>
<html>
<head>
    <title>Complec City - Log In</title>
    <style type="text/css">
        .form {
            background-color: black;
            color: white;
            margin: 4%;
            padding: 20px;
            opacity: .9;

        }

        #div1 {
            background-color: black;
            color: white;
            opacity: .9;
            width: 300px;

        }
        div {
            background-color: black;
            color: white;

        }
        p {
            font-family: arial;
        }
        h {
            font-family: impact;
            padding: 10px;
            font-size: 40px;
        }
        p#footer-txt {
            text-align: center;
            color: #303032;
            font-family: arial;
            font-size: 12px;
            padding: 0 32px;
            background-color: Black;
            color: white;
            margin-top: 21%;
            opacity: .9;
        }
        .home{
            font-family: impact;
            padding: 10px;
            font-size: 40px;
            text-decoration: none;
            color: white;
        }

    </style>


</head>
<body>

<div >
    <!--<a class="home" href="<?php echo e(url('/')); ?>">Complec-City</a>-->

</div>
<?php echo e(Form::open(array('route' => 'session.store'))); ?>

<input type ="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<?php echo $__env->make('alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div>
    <?php echo e(Form::label('uname','Username')); ?>

    <?php echo e(Form::text('uname',
    Input::old('uname')/*,
     ['placeholder' => 'Enter your username',
    'autofocus' => 'autofocus']*/)); ?>

</div>
<div>
    <?php echo e(Form::label('password','Password')); ?>

    <?php echo e(Form::password('password'/*, ['placeholder' => 'Enter your password']*/)); ?>

    <br>
    <?php echo e(Form::label('remember_me','Remember me')); ?>

    <?php echo e(Form::checkbox('remember_me','Remember me')); ?>

</div>
<div>
    <?php echo e(Form::submit('Login')); ?>

</div>
<?php echo e(Form::close()); ?>

<p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>
    <br>
    <a href="@">Contact us</a>
    <a href="@"> </a>
    <a href="@"> Developers </a>

    <a href="@"> Privacy </a>
    <a href="@"> Terms </a>
    <a href="@"> Help </a>

</p>
</body>
</html>
