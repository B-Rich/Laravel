<?php
session_start();
if(array_key_exists("user", $_SESSION)){
    $sessionUser = $_SESSION['user'];
    $sessionUserNm = $_SESSION['userNm'];
    echo "Welcome, ".$sessionUserNm;
}else{
    header('Location: index');
    exit;
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <body background="bckgrnd.jpg">
        <title>View available courses</title>
        </head>
    <body>
        <table border="black">
            <tr>
                <th>Course Name</th>
                <th>Course Code</th>
                <th>Description</th>
            </tr>
            <?php
            require_once ("DB/DataBase.php");
            $clntID = DataBase::getInstance()->getClientID($sessionUser);
            $result = DataBase::getInstance()->getCourses();
            while($row = mysqli_fetch_array($result)):
                $shrt = array('Name','Code','Description');
                for($i = 0; $i < count($shrt); $i++){
                 echo '<th>'.htmlentities($row[$shrt[$i]]).'</th>';
                }
                $crsID = $row['ID'];
                //echo "<td>GameID=" . $crsID . "</td>";
            ?>
            <td>
                <form name ="customizeCollection" action ="addCourse" method="POST">
                    <input type ="hidden" name ="courseID" value ="<?php echo $crsID;?>"/>
                    <input type ="hidden" name ="clientID" value ="<?php echo $clntID;?>"/>
                    <input type ="submit" name ="addCourse" value ="Add course"/>
                </form>
            </td>
            <?php
            echo "</tr>\n";
            endwhile;
            mysqli_free_result($result);
            ?>
        </table>
        <form name="AddItemToCollection" action="editCourses">
            <input type ="submit" value ="Previous Page"/>
        </form>
        <form name="ReturnToHomePage" action="index">
            <input type ="submit" value ="Return To Home Page"/>
        </form>
    </body>
</html>
