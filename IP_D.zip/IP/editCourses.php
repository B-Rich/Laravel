<?php
session_start();
if (array_key_exists("user", $_SESSION)) {
    $sessionUser = $_SESSION['user'];
    $sessionUserNm = $_SESSION['userNm'];
    echo "Welcome, " . $sessionUserNm;
} else {
    header('Location: index');
    exit;
}
if ($_SESSION['clientType'] == 'INST') {
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    //echo $_POST['goto'];
    $_SESSION['crsCode'] = $_POST['crsCode'];
    $_SESSION['crsName'] = $_POST['crsName'];
    if($_POST['goto'] == 'addQuestion'){
        header('Location: addQuestion');
    }elseif($_POST['goto'] == 'viewEnrolled') {
        header('Location: viewEnrolled');
    }else{
        header('Location: index');
    }
    exit;
}}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <body background="bckgrnd.jpg">
    <title>Edit your courses</title>
</head>
<body>
    <table border="black">
        <tr>
        <tr>
            <th>Course Name</th>
            <th>Course Code</th>
            <th>Description</th>
            <th>Options</th>
        </tr>
        <?php
        require_once ("DB/DataBase.php");
        $clntID = DataBase::getInstance()->getClientID($sessionUser);
        //add function
        if ($_SESSION['clientType'] == 'INST') {
          $result = DataBase::getInstance()->getCourses();  
        }else{
        $result = DataBase::getInstance()->getClientCourses($clntID);
        }
        while ($row = mysqli_fetch_array($result)):
            $shrt = array('Name', 'Code', 'Description');
            for ($i = 0; $i < count($shrt); $i++) {
                echo '<th>' . htmlentities($row[$shrt[$i]]) . '</th>';
            }
            //echo"<tr><td></tr>";
            $crsCode = $row['Code'];
            $crsName = $row['Name'];
            ?>
            <td>
                <?php
                if ($_SESSION['clientType'] == 'INST') {
                    echo "<form name='Add Question' action='editCourses' method='POST'>
                            <input type ='hidden' name ='crsCode' value ='$crsCode'>
                            <input type ='hidden' name ='crsName' value ='$crsName'>
                            <input type ='hidden' name ='goto' value ='addQuestion'>
                            <input type ='submit' value ='Add Question'/>
                        </form>";
                    echo "<form name='Enrolled Students' action='editCourses' method='POST'>
                            <input type ='hidden' name ='courseID' value ='$crsCode'>
                            <input type ='hidden' name ='crsName' value ='$crsName'>
                            <input type ='hidden' name ='goto' value ='viewEnrolled'>
                            <input type ='submit' value ='Enrolled Students'/>
                        </form>";
                } else {
                    echo "<form name ='Remove Course' action ='removeCourse' method='POST'>
                    <input type ='hidden' name ='courseID' value =$crsCode/>
                    <input type ='hidden' name ='clientID' value ='$clntID'/>
                    <input type ='submit' name ='cstColl' value ='Remove'/>
                </form>
                <form name ='Take test' action ='takeTest' method='POST'>
                    <input type ='hidden' name ='courseID' value ='<?php echo $crsCode;?>'/>
                    <input type ='hidden' name ='clientID' value ='<?php echo $clntID;?>'/>
                    <input type ='submit' name ='cstColl' value ='Take Test'/>
                </form>";
                }
                ?>
            </td>
            <?php
            echo "</tr>\n";
        endwhile;
        //echo "<p>Course=" . $_SESSION['crsCode'] . "</p>";
        mysqli_free_result($result);
        ?>
    </table>
    <?php if ($_SESSION['clientType'] == 'INST'){
             echo '<form name="Add new course" action="addNewCourse">
                  <input type ="submit" value ="Add new course"/></form>';
    }else{
        echo '<form name="AddItemToCollection" action="courseList">
        <input type ="submit" value ="Add course"/></form>';
    }
?>  
    <a href="home"><button>Back</button></a>
    <form name="ReturnToHomePage" action="index">
        <input type ="submit" value ="Logout"/>
    </form>
</body>
</html>
