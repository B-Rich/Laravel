<?php
session_start();
if (array_key_exists("user", $_SESSION)) {
    $sessionUser = $_SESSION['user'];
    $sessionUserNm = $_SESSION['userNm'];
    echo "Welcome, " . $sessionUserNm;
} else {
    header('Location: index');
    exit;
}
?>
<?php
require_once ("DB/DataBase.php");
if ($_SERVER ['REQUEST_METHOD'] == "POST") {
    session_start();
    $_SESSION['user'] = $_POST['user'];
    header('Location: editCourses');
    exit;
}
?>
<!DOCTYPE HTML>
<html>
    <body>
        <title>Welcome, <?php echo $sessionUserNm; ?></title>
        <br>My Courses<br>
        <?php
        require_once("DB/DataBase.php");
        $clntID = DataBase::getInstance()->getClientID($sessionUser);
        //echo "<br><br>$clntID";
        if (!$clntID) {
            exit("The client " . $sessionUser . " is not found. Please check the spelling and try again");
        }
        ?>
        <br>
        Client info:
        <table border="black">
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Profession</th>
            </tr>
            <?php
            $result = DataBase::getInstance()->getClientInfo($clntID);
            try {
                while ($row = mysqli_fetch_array($result)) {
                    $clntType = $row['Profession'];
                    $_SESSION['clientType'] = $clntType;
                    $shrt = array('FirstName', 'LastName', 'Gender', 'DateOfBirth', 'Profession');
                    for ($i = 0; $i < count($shrt); $i++) {
                        if ($row[$shrt[$i]] == 'INST') {
                            echo '<th>Instructor</th>';
                        } elseif ($row[$shrt[$i]] == 'STDT') {
                            echo '<th>Student</th>';
                        } else {
                            echo '<th>' . htmlentities($row[$shrt[$i]]) . '</th>';
                        }
                    }
                    echo "</tr>\n";
                }
                mysqli_free_result($result);
            } catch (Exception $e) {
                echo "<script>alert('You are currently not enrolled in any courses. Please enroll.'); location.href='home.php'</script>";
            }
            ?>
        </table>
        <br>
        Courses:
        <table border="black">
            <tr>
                <th>Course Name</th>
                <th>Course Code</th>
                <th>Description</th>
            </tr>
            <?php
            $result = DataBase::getInstance()->getClientCourses($clntID);
            try {
                while ($row = mysqli_fetch_array($result)) {
                    $shrt = array('Name', 'Code', 'Description');
                    for ($i = 0; $i < count($shrt); $i++) {
                        echo '<th>' . htmlentities($row[$shrt[$i]]) . '</th>';
                    }
                    echo "</tr>\n";
                }
                mysqli_free_result($result);
            } catch (Exception $e) {
                echo "<script>alert('You are currently not enrolled in any courses. Please enroll.'); location.href='home.php'</script>";
            }
            ?>
        </table>
        <form name="Edit Courses" action="editCourses">
            <input type ="submit" value ="Edit Courses"/>
        </form>
    </body>
</html>