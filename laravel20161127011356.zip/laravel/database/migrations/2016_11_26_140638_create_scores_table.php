<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScoresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /*CREATE TABLE IF NOT EXISTS scores(
uid MEDIUMINT not null,
gid SMALLINT not null,
score BIGINT not null,
PRIMARY KEY(uid, gid),
FOREIGN KEY(uid) REFERENCES users(uid) ON DELETE CASCADE,
FOREIGN KEY(gid) REFERENCES games(gid) ON DELETE CASCADE);*/
        Schema::create('scores', function (Blueprint $table) {
            $table->mediumInteger('uid')->unsigned();
            $table->smallInteger('gid')->unsigned(); //add unsigned because auto increment
            $table->bigInteger('score');
            $table->primary(['gid','uid']);
            $table->foreign('uid')
                ->references('uid')->on('users')
                ->onDelete('cascade');
            $table->foreign('gid')
                ->references('gid')->on('games')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('scores');
    }
}
