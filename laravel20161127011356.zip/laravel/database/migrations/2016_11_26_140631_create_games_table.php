<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGamesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /*gid SMALLINT not null AUTO_INCREMENT,
gname VARCHAR(64) not null,
description VARCHAR(256),
PRIMARY KEY(gid));
*/
        Schema::create('games', function (Blueprint $table) {
            $table->smallIncrements('gid');
            $table->string('gname', 64)->unique();
            $table->string('description', 256);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('games');
    }
}
