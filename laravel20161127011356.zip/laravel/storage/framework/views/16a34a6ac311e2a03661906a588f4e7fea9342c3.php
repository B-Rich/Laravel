<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Complec City's Haven</title>
    <style type="text/css">
        div {
            background-color: black;
            color: white;

        }
        p {
            font-family: arial black;
            font-size: 50px;
            background-color: black;
            color: white;
            text-align: center;
            padding: 2s0px;
            margin-bottom: 60;
        }
        h {
            font-family: impact;
            padding: 10px;
            font-size: 40px;
            opacity: .9;
        }
        body {
            background-color: black;
        }
        p#footer-txt {
            text-align: center;
            color: #303032;
            font-family: arial;
            font-size: 12px;
            padding: 0 32px;
            background-color: Black;
            color: white;
            margin-top: .5%;

        }

        button {
            text-align: center;
            margin: auto;
            display: inline-block;
            padding: 10px;
            width: 100px;
            height: 50px;
            background-color: black;
            font-family: impact;
            color: white;
            border: none;
            opacity: .4;
            font-size: 30px;
        }
        .h, button a {
            text-decoration: none;
            color: white;
            font-family: impact;
            font-size: 15px;
            display: inline-block;

        }
        a: hover {
            background-color: red;
            text-decoration: none;
            color: white;
        }



    </style>
</head>
<body>
<div >
    <img src="xD.jpg" alt="Logo" title="Complec-City" width="400" height="180">
</div>
<h1> Account activation </h1> <br>
<p> Thank you for signing up. Please follow the link below to confirm your E-mail address</p>
<!--<center><a class="h" href="<?php echo e(url('/activate'.$confirmation_token)); ?>" style="font-size: 25px"> Activate your account </a></center>-->
<center><a class="h" href="<?php echo e(url('activate/'.$confirmation_token)); ?>" style="font-size: 25px"> Activate your account </a></center>
<br>
<br>
<br>

</div>
</body>
</html>