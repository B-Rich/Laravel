<!--

<?php $__env->startSection('content'); ?>-->
<!DOCTYPE html>
<html>
<head>
    <title>Complec City - Sign Up</title>
    <style type="text/css">
        .form {
            background-color: black;
            color: white;
            margin: 4%;
            padding: 30px;
            opacity: .9;

        }

        div {
            background-color: black;
            color: white;
            opacity: .9;

        }
        p {
            font-family: arial;
        }
        h {
            font-family: impact;
            padding: 10px;
            font-size: 40px;
        }
        p#footer-txt {
            text-align: center;
            color: #303032;
            font-family: arial;
            font-size: 12px;
            padding: 0 32px;
            background-color: Black;
            color: white;

            opacity: .9;
        }
        .home{
            font-family: impact;
            padding: 10px;
            font-size: 40px;
            text-decoration: none;
            color: white;
        }
        a.home:hover{
            font-family: impact;
            padding: 10px;
            font-size: 40px;
            text-decoration: none;
            color: white;
        }

    </style>


</head>
<body>

<div>
    <a class="home" href="<?php echo e(url('/')); ?>">Complec-City</a>

</div>
<form role="form" method="POST" action="<?php echo e(url('/register')); ?>">
<div class="form">
    <p> Username </p>
    <input type="text" name=""> <br>
    <p> Password </p>
    <input type="Password" name=""> <br>
    <p> E-mail </p>
    <input type="E-mail" name=""> <br>
    <p> Confirmation </p>
    <input type="E-mail" name=""> <br>
    <p> Gender </p>
    <select>
        <option> Default </option>
        <option> Male </option>
        <option> Female </option>
    </select> <br> <br>

    <input type="submit" name="" value="Submit" style="float: center; color: black;">

</div>
</form>

<p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>
    <br>
    <a href="@">Contact us</a>
    <a href="@"> </a>
    <a href="@"> Developers </a>

    <a href="@"> Privacy </a>
    <a href="@"> Terms </a>
    <a href="@"> Help </a>

</p>
</body>
</html>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>