<?php if(Session::has('alert')): ?>
    <div class="alert" role="alert">
        <?php echo e(Session::get('alert')); ?>

    </div>
<?php endif; ?>