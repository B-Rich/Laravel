@if(Session::has('alert'))
    <div class="alert" role="alert">
        {{Session::get('alert')}}
    </div>
@endif