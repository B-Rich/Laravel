<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class scores extends Model
{
    //
}
