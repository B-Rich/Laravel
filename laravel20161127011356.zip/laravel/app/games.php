<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class games extends Model
{
    //
}
